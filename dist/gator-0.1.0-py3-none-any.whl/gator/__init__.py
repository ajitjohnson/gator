from .generateThumbnails import generateThumbnails
from .cloneFolder import cloneFolder
from .generateTraining import generateTraining